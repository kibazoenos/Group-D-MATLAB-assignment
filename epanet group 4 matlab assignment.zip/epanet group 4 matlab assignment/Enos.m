% =========================================================================
% NEW PIPE DESIGN TOPOLOGY SCHEMATIC MAPPER
% =========================================================================
clear; clc; close all;

%% 1. SET DEFINED COORDINATES FOR ALL NODES [X, Y]
% Main vertical pipeline trunk spine
Coord_Source      = [0,10.5];
Coord_Junc_Login  = [0, 7.5];
Coord_Junc_Zalene = [0, 5.0];
Coord_Junc_Univ   = [0, 2.5];
Coord_Junc_TTee   = [0, 0.5];

% End delivery locations
Coord_Login       = [-4, 7.5];
Coord_Zalene      = [4, 5.0];
Coord_University  = [-4, 2.5];
Coord_TripleTee   = [4, 0.5];

%% 2. INITIALIZE MAP FIGURE
figure('Color', 'w', 'Position', [100, 100, 650, 600]);
hold on; 
grid on;

%% 3. PLOT ALL PIPE CONNECTIONS (BRANCHES)
% --- Main Vertical Spine Pipelines ---
plot([Coord_Source(1), Coord_Junc_Login(1)], [Coord_Source(2), Coord_Junc_Login(2)], 'k-', 'LineWidth', 3.5);
plot([Coord_Junc_Login(1), Coord_Junc_Zalene(1)], [Coord_Junc_Login(2), Coord_Junc_Zalene(2)], 'k-', 'LineWidth', 3.5);
plot([Coord_Junc_Zalene(1), Coord_Junc_Univ(1)], [Coord_Junc_Zalene(2), Coord_Junc_Univ(2)], 'k-', 'LineWidth', 3.5);
plot([Coord_Junc_Univ(1), Coord_Junc_TTee(1)], [Coord_Junc_Univ(2), Coord_Junc_TTee(2)], 'k-', 'LineWidth', 3.5);

% --- Horizontal Side Branch Pipes ---
% Branch to Login (Left)
plot([Coord_Junc_Login(1), Coord_Login(1)], [Coord_Junc_Login(2), Coord_Login(2)], 'b-', 'LineWidth', 2.5);
% Branch to Zalene (Right)
plot([Coord_Junc_Zalene(1), Coord_Zalene(1)], [Coord_Junc_Zalene(2), Coord_Zalene(2)], 'b-', 'LineWidth', 2.5);
% Branch to University (Left)
plot([Coord_Junc_Univ(1), Coord_University(1)], [Coord_Junc_Univ(2), Coord_University(2)], 'b-', 'LineWidth', 2.5);
% Branch to Triple Tee (Right)
plot([Coord_Junc_TTee(1), Coord_TripleTee(1)], [Coord_Junc_TTee(2), Coord_TripleTee(2)], 'b-', 'LineWidth', 2.5);

%% 4. PLOT AND LABEL ALL NODES
% --- 1. The Water Source (Blue Circle/Oval node) ---
h_source = plot(Coord_Source(1), Coord_Source(2), 'bo', 'MarkerSize', 16, 'MarkerFaceColor', 'b');
text(Coord_Source(1) - 1.2, Coord_Source(2) + 0.6, 'SOURCE', 'FontWeight', 'bold', 'FontSize', 11, 'Color', 'b');

% --- 2. Main Spine T-Junctions (Red Dots) ---
h_junc = plot([Coord_Junc_Login(1), Coord_Junc_Zalene(1), Coord_Junc_Univ(1), Coord_Junc_TTee(1)], ...
              [Coord_Junc_Login(2), Coord_Junc_Zalene(2), Coord_Junc_Univ(2), Coord_Junc_TTee(2)], ...
              'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r');

% --- 3. Delivery Terminals (Green Squares) ---
h_term = plot([Coord_Login(1), Coord_Zalene(1), Coord_University(1), Coord_TripleTee(1)], ...
              [Coord_Login(2), Coord_Zalene(2), Coord_University(2), Coord_TripleTee(2)], ...
              'gs', 'MarkerSize', 12, 'MarkerFaceColor', 'g');

% Text labels for each end location box
text(Coord_Login(1) - 1.5, Coord_Login(2), 'Login', 'FontWeight', 'bold', 'FontSize', 11);
text(Coord_Zalene(1) + 0.4, Coord_Zalene(2), 'Zalene', 'FontWeight', 'bold', 'FontSize', 11);
text(Coord_University(1) - 2.5, Coord_University(2), 'University', 'FontWeight', 'bold', 'FontSize', 11);
text(Coord_TripleTee(1) + 0.4, Coord_TripleTee(2), 'Triple Tee', 'FontWeight', 'bold', 'FontSize', 11);

%% 5. VISUAL CUSTOMIZATION & WINDOW LIMITS
title('Water Supply Network Topology Design', 'FontSize', 13, 'FontWeight', 'bold');
xlabel('Relative X Position');
ylabel('Relative Y Position');

% Fully specified viewing limits so all elements sit perfectly inside the window
xlim([-7, 7]);
ylim([-1, 12]);

% Clean legend configuration
legend([h_source, h_junc, h_term], {'Network Source', 'Pipeline Junctions', 'Delivery Terminal Nodes'}, ...
    'Location', 'northwest', 'FontSize', 10);

% Clean aesthetic look hiding abstract grid ticks
set(gca, 'XTick', [], 'YTick', []);
hold off;
